import { View, Text, StyleSheet } from 'react-native';

export default function SolicitudScreen() {
    return (
        <View style={styles.container}>
            <Text style={styles.titulo}>Solicitudes</Text>
            <Text style={styles.subtitulo}>Aquí puedes gestionar tus solicitudes universitarias</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f8fafc',
        padding: 20,
    },
    titulo: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#1e293b',
        marginBottom: 8,
    },
    subtitulo: {
        fontSize: 14,
        color: '#64748b',
    },
});